"""Transcription progress tracker with WebSocket support."""
import asyncio
import json
import time
from typing import Dict, Optional

# Global registry of active transcription jobs
_jobs: Dict[str, dict] = {}


def create_job(protocol_id: str, task_id: str) -> dict:
    """Register a new transcription job."""
    job = {
        "task_id": task_id,
        "protocol_id": protocol_id,
        "status": "starting",  # starting, processing, completed, failed, cancelled
        "progress": 0,        # 0..100
        "message": "Инициализация...",
        "segments_count": 0,
        "started_at": time.time(),
        "updated_at": time.time(),
    }
    _jobs[task_id] = job
    return job


def update_job(task_id: str, status: str = None, progress: int = None, 
               message: str = None, segments_count: int = None):
    """Update job status."""
    if task_id not in _jobs:
        return
    job = _jobs[task_id]
    if status is not None:
        job["status"] = status
    if progress is not None:
        job["progress"] = max(0, min(100, progress))
    if message is not None:
        job["message"] = message
    if segments_count is not None:
        job["segments_count"] = segments_count
    job["updated_at"] = time.time()


def get_job(task_id: str) -> Optional[dict]:
    """Get job status."""
    return _jobs.get(task_id)


def cancel_job(task_id: str) -> bool:
    """Mark job as cancelled."""
    if task_id not in _jobs:
        return False
    _jobs[task_id]["status"] = "cancelled"
    _jobs[task_id]["message"] = "Отменено пользователем"
    _jobs[task_id]["updated_at"] = time.time()
    return True


def cleanup_old_jobs(max_age_seconds: int = 3600):
    """Remove jobs older than max_age_seconds."""
    now = time.time()
    to_delete = [
        task_id for task_id, job in _jobs.items()
        if now - job["updated_at"] > max_age_seconds
    ]
    for task_id in to_delete:
        del _jobs[task_id]
    return len(to_delete)
